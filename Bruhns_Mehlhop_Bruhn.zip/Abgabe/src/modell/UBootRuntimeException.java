package modell;

@SuppressWarnings("serial")
public class UBootRuntimeException extends RuntimeException{

}
