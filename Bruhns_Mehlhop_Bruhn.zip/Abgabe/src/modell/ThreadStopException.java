package modell;


@SuppressWarnings("serial")
public class ThreadStopException extends UBootRuntimeException{
}
